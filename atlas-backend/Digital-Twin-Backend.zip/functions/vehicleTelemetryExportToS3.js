exports = function (args) {
  
  // https://www.mongodb.com/developer/products/atlas/automated-continuous-data-copying-from-mongodb-to-s3/
  
   const datalake = context.services.get("Connected-Vehicle-Telemetry-Data");
   const db = datalake.db("Digital-Twin-Hot")
   const events = db.collection("Telemetry");

   const pipeline = [
 {
    '$project': {
      '_id': false,
      'timestamp': true,
      'vehicle_id': '$device_id', 
      'voltage': true, 
      'current': true
    }
  }, {
    '$out': {
      's3': {
        'bucket': 'partner-demo', 
        'region': 'us-east-1', 
        'filename': 'ist/sensor', 
        'format': {
          'name': 'csv', 
          'maxFileSize': '10GB'
        }
      }
    }
  }
   ];

   return events.aggregate(pipeline);
};